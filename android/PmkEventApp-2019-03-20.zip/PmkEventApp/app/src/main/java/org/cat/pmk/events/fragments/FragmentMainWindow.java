package org.cat.pmk.events.fragments;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.GetChars;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import org.cat.pmk.events.MainActivity;
import org.cat.pmk.events.R;

import java.util.List;

public class FragmentMainWindow extends Fragment {

    Activity mainActivity;
    LocationListener locListener;
    LocationManager locationManager;
    double longitudeBest, latitudeBest;


    public FragmentMainWindow(Activity mainActivity) {
        this.mainActivity = mainActivity;

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fgmt_main_window, container, false);
    }

    // This event is triggered soon after onCreateView().
    // Any view setup should occur here.  E.g., view lookups and attaching view listeners.
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        // Setup any handles to view objects here
        // EditText etFoo = (EditText) view.findViewById(R.id.etFoo);

        locationManager =  (LocationManager) view.getContext().getApplicationContext().getSystemService(Context.LOCATION_SERVICE);

        Log.d("button", "providers: " + locationManager.getProviders(false));



        Log.d("button", "providers: " + locationManager.getProviders(false));



        Button btn = (Button) view.findViewById(R.id.newOrderBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            private double[] getGPS() {
                List<String> providers = locationManager.getProviders(true);

                Location l = null;

                for (int i=providers.size()-1; i>=0; i--) {
                    l = locationManager.getLastKnownLocation(providers.get(i));
                    if (l != null) break;
                }

                double[] gps = new double[2];
                if (l != null) {
                    gps[0] = l.getLatitude();
                    gps[1] = l.getLongitude();
                }

                return gps;
            }

            @Override
            public void onClick(View view) {
                Log.d("button", "onClick: ");

                // check permissions
                if (ContextCompat.checkSelfPermission(view.getContext().getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    Log.d("button", "permission missing: ACCESS_FINE_LOCATION ");

                    // Permission is not granted
                    // Should we show an explanation?
                    if (ActivityCompat.shouldShowRequestPermissionRationale(mainActivity,
                            Manifest.permission.READ_CONTACTS)) {
                        // Show an explanation to the user *asynchronously* -- don't block
                        // this thread waiting for the user's response! After the user
                        // sees the explanation, try again to request the permission.
                    } else {
                        // No explanation needed; request the permission
                        ActivityCompat.requestPermissions(mainActivity,
                                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                11213);

                        // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                        // app-defined int constant. The callback method gets the
                        // result of the request.
                    }
                }


                Log.i("tag", "location: " + getGPS()[0]);


            }
        });

    }





    public class PmkLocationListener implements LocationListener {
        final String LOG_LABEL = "Location Listener>>";

        private Context context;

        public PmkLocationListener(Context context) {
            this.context = context;
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }

        @Override
        public void onLocationChanged(Location location) {
            Log.d("loc", LOG_LABEL + "Location Changed");
            if (location != null) {
                double longitude = location.getLongitude();
                Log.d("log", LOG_LABEL + "Longitude:" + longitude);
                Toast.makeText(context.getApplicationContext(), "Long::" + longitude, Toast.LENGTH_SHORT).show();
                double latitude = location.getLatitude();
                Toast.makeText(context.getApplicationContext(), "Lat::" + latitude, Toast.LENGTH_SHORT).show();
                Log.d("loc", LOG_LABEL + "Latitude:" + latitude);

                cleanUp();
            }
        }

        private void cleanUp(){
            // This needs to be done to stop getting the location data and save the
            // battery power.
            if (null != locListener && null != locationManager)
            {
                locationManager.removeUpdates(locListener);
                locListener = null;
            }
        }

    }




}
